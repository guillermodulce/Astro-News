/*
This Codepen is in the Public Domain.
You can use it for whatever purpose you like, except evil.
*/