A Pen created at CodePen.io. You can find this one at https://codepen.io/pieter-biesemans/pen/xqVBdK.

 Orbital icons based on work of the fantastic Rob Whotton.  https://dribbble.com/shots/2405886-Orbital-Icons